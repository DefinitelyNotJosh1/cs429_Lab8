All Python code written in Python 3.11.9

Krasnogo27.Lab8.pdf - write-up

tut1.py - TensorFlow beginner tutorial

tut2.py - TensorFlow CNN tutorial

tf_perceptron_redo.py - redo of perceptron assignment with TensorFlow

tf_CNN.py - redo of perceptron assignment with TensorFlow CNN image classification